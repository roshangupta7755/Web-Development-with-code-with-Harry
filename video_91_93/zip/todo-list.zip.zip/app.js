// To-Do List Application JavaScript

class TodoApp {
    constructor() {
        this.tasks = [];
        this.nextId = 1;
        this.init();
    }

    init() {
        this.bindElements();
        this.addEventListeners();
        this.renderTasks();
        
        // Focus the input field after initialization
        setTimeout(() => {
            if (this.taskInput) {
                this.taskInput.focus();
            }
        }, 100);
    }

    bindElements() {
        this.taskInput = document.getElementById('taskInput');
        this.addTaskBtn = document.getElementById('addTaskBtn');
        this.tasksContainer = document.getElementById('tasksContainer');
        this.totalTasksSpan = document.getElementById('totalTasks');
        this.completedTasksSpan = document.getElementById('completedTasks');
        
        // Verify all elements are found
        if (!this.taskInput || !this.addTaskBtn || !this.tasksContainer || 
            !this.totalTasksSpan || !this.completedTasksSpan) {
            console.error('Could not find all required DOM elements');
        }
    }

    addEventListeners() {
        if (this.addTaskBtn) {
            this.addTaskBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.addTask();
            });
        }
        
        if (this.taskInput) {
            this.taskInput.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    this.addTask();
                }
            });
            
            // Also listen for keypress as backup
            this.taskInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    this.addTask();
                }
            });
        }
    }

    addTask() {
        if (!this.taskInput) {
            console.error('Task input element not found');
            return;
        }
        
        const taskText = this.taskInput.value.trim();
        console.log('Adding task:', taskText); // Debug log
        
        // Input validation
        if (!taskText) {
            this.taskInput.focus();
            console.log('Empty task text, focusing input');
            return;
        }

        // Create new task object
        const newTask = {
            id: this.nextId++,
            text: taskText,
            completed: false,
            createdAt: new Date()
        };

        // Add to tasks array
        this.tasks.push(newTask);
        console.log('Task added, total tasks:', this.tasks.length);
        
        // Clear input field
        this.taskInput.value = '';
        this.taskInput.focus();
        
        // Re-render tasks and update stats
        this.renderTasks();
        this.updateStats();
    }

    toggleTask(taskId) {
        console.log('Toggling task:', taskId);
        const task = this.tasks.find(t => t.id === taskId);
        if (task) {
            task.completed = !task.completed;
            this.renderTasks();
            this.updateStats();
        }
    }

    deleteTask(taskId) {
        console.log('Deleting task:', taskId);
        const taskElement = document.querySelector(`[data-task-id="${taskId}"]`);
        
        if (taskElement) {
            // Add removing animation class
            taskElement.classList.add('removing');
            
            // Wait for animation to complete, then remove from DOM and array
            setTimeout(() => {
                this.tasks = this.tasks.filter(t => t.id !== taskId);
                this.renderTasks();
                this.updateStats();
            }, 250);
        } else {
            // If no animation, just remove immediately
            this.tasks = this.tasks.filter(t => t.id !== taskId);
            this.renderTasks();
            this.updateStats();
        }
    }

    renderTasks() {
        console.log('Rendering tasks, count:', this.tasks.length);
        
        if (!this.tasksContainer) {
            console.error('Tasks container not found');
            return;
        }

        // Clear container first
        this.tasksContainer.innerHTML = '';

        if (this.tasks.length === 0) {
            this.renderEmptyState();
            return;
        }

        // Create task elements
        this.tasks.forEach(task => {
            const taskElement = this.createTaskElement(task);
            this.tasksContainer.appendChild(taskElement);
        });

        this.updateStats();
    }

    createTaskElement(task) {
        const taskDiv = document.createElement('div');
        taskDiv.className = `task-item ${task.completed ? 'completed' : ''}`;
        taskDiv.setAttribute('data-task-id', task.id);
        
        taskDiv.innerHTML = `
            <div class="task-checkbox ${task.completed ? 'checked' : ''}" role="button" tabindex="0" aria-label="Toggle task completion">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
                    <polyline points="20,6 9,17 4,12"></polyline>
                </svg>
            </div>
            <div class="task-text" title="${this.escapeHtml(task.text)}">
                ${this.escapeHtml(task.text)}
            </div>
            <button class="delete-btn" aria-label="Delete task" title="Delete task">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="3,6 5,6 21,6"></polyline>
                    <path d="m19,6v14c0,1-1,2-2,2H7c-1,0-2-1-2-2V6m3,0V4c0-1,1-2,2-2h4c1,0,2,1,2,2v2"></path>
                </svg>
            </button>
        `;

        // Add event listeners with proper binding
        const checkbox = taskDiv.querySelector('.task-checkbox');
        const deleteBtn = taskDiv.querySelector('.delete-btn');

        if (checkbox) {
            checkbox.addEventListener('click', (e) => {
                e.preventDefault();
                this.toggleTask(task.id);
            });
            checkbox.addEventListener('keypress', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    this.toggleTask(task.id);
                }
            });
        }

        if (deleteBtn) {
            deleteBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.deleteTask(task.id);
            });
        }

        // Add animation class after a small delay
        setTimeout(() => {
            taskDiv.classList.add('adding');
        }, 10);

        return taskDiv;
    }

    renderEmptyState() {
        if (!this.tasksContainer) return;
        
        this.tasksContainer.innerHTML = `
            <div class="empty-state">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                    <path d="M9 11l3 3l8-8"></path>
                    <path d="M21 12c0 4.97-4.03 9-9 9s-9-4.03-9-9s4.03-9 9-9c1.955 0 3.751.63 5.2 1.7"></path>
                </svg>
                <h3>No tasks yet</h3>
                <p>Add your first task above to get started!</p>
            </div>
        `;
    }

    updateStats() {
        const totalTasks = this.tasks.length;
        const completedTasks = this.tasks.filter(task => task.completed).length;

        // Update stats display
        if (this.totalTasksSpan) {
            this.totalTasksSpan.textContent = `${totalTasks} total`;
        }
        if (this.completedTasksSpan) {
            this.completedTasksSpan.textContent = `${completedTasks} completed`;
        }
        
        // Update document title with task count
        document.title = totalTasks > 0 ? `To-Do List (${totalTasks})` : 'To-Do List';
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // Public methods for debugging/console access
    getTasks() {
        return [...this.tasks]; // Return copy
    }

    clearAllTasks() {
        this.tasks = [];
        this.renderTasks();
        this.updateStats();
    }

    addSampleTasks() {
        const sampleTasks = [
            'Review project documentation',
            'Prepare presentation slides',
            'Schedule team meeting',
            'Update task tracking system',
            'Plan next sprint goals'
        ];

        sampleTasks.forEach(taskText => {
            const newTask = {
                id: this.nextId++,
                text: taskText,
                completed: false,
                createdAt: new Date()
            };
            this.tasks.push(newTask);
        });

        this.renderTasks();
        this.updateStats();
    }
}

// Initialize the application when DOM is loaded
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initApp);
} else {
    initApp();
}

function initApp() {
    console.log('Initializing To-Do List App...');
    window.todoApp = new TodoApp();
    
    // Add some helpful console methods for demo purposes
    console.log('To-Do List App initialized!');
    console.log('Available methods:');
    console.log('- todoApp.addSampleTasks() - Add sample tasks for demo');
    console.log('- todoApp.clearAllTasks() - Clear all tasks');
    console.log('- todoApp.getTasks() - View current tasks');
}

// Handle page visibility changes to maintain focus
document.addEventListener('visibilitychange', () => {
    if (!document.hidden && window.todoApp && window.todoApp.taskInput) {
        window.todoApp.taskInput.focus();
    }
});